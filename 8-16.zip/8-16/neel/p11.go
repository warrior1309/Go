package main

import "fmt"

type shap interface {
	Area()
	Perimeter()
}

type Circle struct {
	radius float64
}

const pi = 3.14

func (c Circle) Area() float64 {
	return pi * c.radius * c.radius
}

func (c Circle) Perimeter() float64 {
	return 2 * pi * c.radius
}

type Rectangle struct {
	width, height float64
}

func (r Rectangle) Area() float64 {
	return r.width * r.height
}
func (r Rectangle) Perimeter() float64 {
	return 2 * (r.width + r.height)
}

func printInfo(s shap) {
	fmt.Println("Area: ", s.Area())
	fmt.Println("Perimeter: ", s.Perimeter())
}

func main() {
	fmt.Println("Ans \n\n")

	fmt.Println("\n\n")
	c:= Circle{radius:12}
	
}