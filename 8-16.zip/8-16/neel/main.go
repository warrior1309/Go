package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"text/template"
)

type data struct {
	Id   int    `json:"id"`
	Name string `json:"name"`
	City string `json:"city"`
}

var datas []data

func main() {
	fdata, _ := os.ReadFile("./data.json")
	json.Unmarshal(fdata, &datas)
	http.HandleFunc("/" , func(w http.ResponseWriter,r*http.Request) {
		tmpl , _ := template.ParseFiles( "index.html")
		tmpl.Execute(w, datas)
	})
	fmt.Println("Server Is Running on 8000")
	http.ListenAndServe(":8000" , nil)
}